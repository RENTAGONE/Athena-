/// <reference types="vite/client" />
/// <reference types="vite-plugin-pwa/client" />

/** Build timestamp injected by vite.config.ts (`define`). */
declare const __BUILD_STAMP__: string;
